#include <stdio.h>
#include <stdlib.h>
/* test program */
int main(void)
{
    printf("Hello 800938386 \n");
    printf("How are you? \n");
    /*This 2nd print statement should print "How are you?" */
    return(EXIT_SUCCESS);
}